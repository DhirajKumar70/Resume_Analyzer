import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta
from config.database import get_database_connection
from io import BytesIO

_NO_MB = {"displayModeBar": False}   # shared Plotly config


class DashboardManager:

    def __init__(self):
        self.conn   = get_database_connection()
        self.colors = {
            "primary":    "#4CAF50", "secondary": "#2196F3",
            "warning":    "#FFA726", "danger":    "#F44336",
            "info":       "#00BCD4", "success":   "#66BB6A",
            "purple":     "#9C27B0", "background":"#1E1E1E",
            "card":       "#2D2D2D", "text":      "#FFFFFF",
            "subtext":    "#B0B0B0",
        }

    # ── DB helpers ─────────────────────────────────────────────────────────────

    def get_quick_stats(self):
        c = self.conn.cursor()
        c.execute("SELECT COUNT(*) FROM resume_data")
        total = c.fetchone()[0]
        c.execute("SELECT AVG(ats_score) FROM resume_analysis")
        avg_ats = c.fetchone()[0] or 0
        c.execute("SELECT COUNT(*) FROM resume_analysis WHERE ats_score >= 70")
        high = c.fetchone()[0]
        rate = (high / total * 100) if total > 0 else 0
        return {
            "Total Resumes":  f"{total:,}",
            "Avg ATS Score":  f"{avg_ats:.1f}%",
            "High Performing":f"{high:,}",
            "Success Rate":   f"{rate:.1f}%",
        }

    def get_trend_indicators(self):
        c = self.conn.cursor()
        indicators = {}
        queries = {
            "resumes": """
                SELECT (COUNT(*) - (
                    SELECT COUNT(*) FROM resume_data
                    WHERE created_at < date('now','-7 days')
                )) * 100.0 / NULLIF((
                    SELECT COUNT(*) FROM resume_data
                    WHERE created_at < date('now','-7 days')
                ),0) FROM resume_data""",
            "ats": """
                SELECT (AVG(ats_score) - (
                    SELECT AVG(ats_score) FROM resume_analysis
                    WHERE created_at < date('now','-7 days')
                )) * 100.0 / NULLIF((
                    SELECT AVG(ats_score) FROM resume_analysis
                    WHERE created_at < date('now','-7 days')
                ),0) FROM resume_analysis""",
        }
        for metric in ["resumes", "ats", "high_performing", "success_rate"]:
            try:
                if metric in queries:
                    c.execute(queries[metric])
                    change = c.fetchone()[0] or 0
                else:
                    change = 0
                indicators[metric] = {
                    "value": abs(round(change, 1)),
                    "icon":  "↑" if change >= 0 else "↓",
                    "class": "trend-up" if change >= 0 else "trend-down",
                }
            except Exception:
                indicators[metric] = {"value": 0, "icon": "→", "class": "trend-neutral"}
        return indicators

    def get_skill_distribution(self):
        c = self.conn.cursor()
        c.execute("""
            WITH RECURSIVE split(skill, rest) AS (
                SELECT '', skills||',' FROM resume_data
                UNION ALL
                SELECT substr(rest,0,instr(rest,',')),
                       substr(rest,instr(rest,',')+1)
                FROM split WHERE rest<>''
            ),
            cats AS (
                SELECT CASE
                    WHEN LOWER(TRIM(skill,'[]" ')) LIKE '%python%'
                      OR LOWER(TRIM(skill,'[]" ')) LIKE '%java%'
                      OR LOWER(TRIM(skill,'[]" ')) LIKE '%javascript%' THEN 'Programming'
                    WHEN LOWER(TRIM(skill,'[]" ')) LIKE '%sql%'
                      OR LOWER(TRIM(skill,'[]" ')) LIKE '%database%' THEN 'Database'
                    WHEN LOWER(TRIM(skill,'[]" ')) LIKE '%aws%'
                      OR LOWER(TRIM(skill,'[]" ')) LIKE '%cloud%' THEN 'Cloud'
                    WHEN LOWER(TRIM(skill,'[]" ')) LIKE '%agile%'
                      OR LOWER(TRIM(skill,'[]" ')) LIKE '%management%' THEN 'Management'
                    ELSE 'Other'
                END as cat, COUNT(*) as cnt
                FROM split WHERE skill<>'' GROUP BY cat
            )
            SELECT cat, cnt FROM cats ORDER BY cnt DESC
        """)
        rows = c.fetchall()
        return [r[0] for r in rows], [r[1] for r in rows]

    def get_job_category_stats(self):
        c = self.conn.cursor()
        c.execute("""
            SELECT COALESCE(target_category,'Other') as cat,
                   COUNT(*) as cnt,
                   ROUND(AVG(CASE WHEN ra.ats_score>=70 THEN 1 ELSE 0 END)*100,1) as rate
            FROM resume_data rd
            LEFT JOIN resume_analysis ra ON rd.id=ra.resume_id
            GROUP BY cat ORDER BY cnt DESC LIMIT 5
        """)
        rows = c.fetchall()
        return [r[0] for r in rows], [r[2] or 0 for r in rows]

    def get_detailed_insights(self):
        c = self.conn.cursor()
        insights = []

        c.execute("""
            SELECT target_category, AVG(ats_score), COUNT(*)
            FROM resume_data rd JOIN resume_analysis ra ON rd.id=ra.resume_id
            GROUP BY target_category ORDER BY AVG(ats_score) DESC LIMIT 1
        """)
        top = c.fetchone()
        if top:
            insights.append({
                "title": "Top Category", "icon": "",
                "description": f"{top[0]} leads with {top[1]:.1f}% avg ATS across {top[2]} submissions",
                "trend_class": "trend-up", "trend_icon": "↑", "trend_value": f"{top[1]:.1f}%",
            })

        c.execute("""
            SELECT
              (SELECT AVG(ats_score) FROM resume_analysis WHERE created_at>=date('now','-7 days')),
              (SELECT AVG(ats_score) FROM resume_analysis WHERE created_at<date('now','-7 days'))
        """)
        sc = c.fetchone()
        if sc and sc[0] and sc[1]:
            ch = sc[0] - sc[1]
            insights.append({
                "title": "Weekly Trend", "icon": "",
                "description": f"ATS scores {'improved' if ch>=0 else 'decreased'} by {abs(ch):.1f}% this week",
                "trend_class": "trend-up" if ch>=0 else "trend-down",
                "trend_icon": "↑" if ch>=0 else "↓", "trend_value": f"{abs(ch):.1f}%",
            })

        return insights

    def get_resume_data(self):
        c = self.conn.cursor()
        try:
            c.execute("""
                SELECT r.id,r.name,r.email,r.phone,r.linkedin,r.github,r.portfolio,
                       r.target_role,r.target_category,r.created_at,
                       a.ats_score,a.keyword_match_score,a.format_score,a.section_score
                FROM resume_data r
                LEFT JOIN resume_analysis a ON r.id=a.resume_id
                ORDER BY r.created_at DESC
            """)
            return c.fetchall()
        except Exception:
            return []

    def get_admin_logs(self):
        c = self.conn.cursor()
        try:
            c.execute("SELECT admin_email,action,timestamp FROM admin_logs ORDER BY timestamp DESC")
            return c.fetchall()
        except Exception:
            return []

    def get_database_stats(self):
        c = self.conn.cursor()
        c.execute("SELECT COUNT(*) FROM resume_data")
        total = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM resume_data WHERE DATE(created_at)=DATE('now')")
        today = c.fetchone()[0]
        c.execute("PRAGMA page_count"); pc = c.fetchone()[0]
        c.execute("PRAGMA page_size");  ps = c.fetchone()[0]
        sz = pc * ps
        size_str = (f"{sz} bytes" if sz < 1024
                    else f"{sz/1024:.1f} KB" if sz < 1024**2
                    else f"{sz/1024**2:.1f} MB")
        return {"total_resumes": total, "today_submissions": today, "storage_size": size_str}

    # ── Charts ────────────────────────────────────────────────────────────────

    def create_enhanced_ats_gauge(self, value):
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta", value=value,
            delta={"reference": 70, "valueformat": ".1f",
                   "increasing": {"color": "#2ecc71"}, "decreasing": {"color": "#e74c3c"}},
            number={"font": {"size": 40, "color": "white"}},
            gauge={
                "axis":        {"range": [0,100], "tickwidth":1, "tickcolor":"white",
                                 "tickfont":{"color":"white"}},
                "bar":         {"color": "#3498db"},
                "bgcolor":     "rgba(0,0,0,0)", "borderwidth": 2, "bordercolor": "white",
                "steps": [{"range":[0,40],"color":"#e74c3c"},
                           {"range":[40,70],"color":"#f1c40f"},
                           {"range":[70,100],"color":"#2ecc71"}],
                "threshold":   {"line":{"color":"white","width":4},"thickness":0.75,"value":70},
            }))
        fig.update_layout(
            title={"text":"ATS Score Performance","font":{"size":22,"color":"white"},"y":0.85},
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font={"color":"white"}, height=350, margin=dict(l=20,r=20,t=80,b=20))
        return fig

    def create_skill_distribution_chart(self):
        categories, counts = self.get_skill_distribution()
        fig = go.Figure(go.Bar(x=categories, y=counts,
                               marker_color=self.colors["info"],
                               text=counts, textposition="auto"))
        fig.update_layout(
            title={"text":"Skill Distribution","y":0.95,"x":0.5,
                   "xanchor":"center","yanchor":"top"},
            height=350, plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color=self.colors["text"]),
            margin=dict(l=40,r=40,t=60,b=40),
            xaxis=dict(showgrid=False, showline=True,
                       linecolor="rgba(255,255,255,.2)", tickfont=dict(size=12)),
            yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,.1)", zeroline=False),
            bargap=0.3)
        return fig

    def create_job_category_chart(self):
        categories, rates = self.get_job_category_stats()
        colors = [self.colors["success"], self.colors["info"],
                  self.colors["warning"], self.colors["purple"],
                  self.colors["secondary"]]
        fig = go.Figure(go.Bar(x=categories, y=rates,
                               marker_color=colors[:len(categories)],
                               text=[f"{r}%" for r in rates], textposition="auto"))
        fig.update_layout(title="Success Rate by Category",
                          paper_bgcolor=self.colors["card"], plot_bgcolor=self.colors["card"],
                          font={"color":self.colors["text"]}, height=300,
                          margin=dict(l=20,r=20,t=50,b=20))
        fig.update_xaxes(title_text="Category",      color=self.colors["text"])
        fig.update_yaxes(title_text="Success Rate %", color=self.colors["text"])
        return fig

    # ── Admin sections ────────────────────────────────────────────────────────

    def render_resume_data_section(self):
        st.markdown("<h2 class='section-title'>Resume Submissions</h2>",
                    unsafe_allow_html=True)
        rows = self.get_resume_data()
        if not rows:
            st.info("No resume submissions yet.")
            return

        cols = ["ID","Name","Email","Phone","LinkedIn","GitHub","Portfolio",
                "Target Role","Target Category","Submission Date",
                "ATS Score","Keyword Match","Format Score","Section Score"]
        df = pd.DataFrame(rows, columns=cols)
        for col in ["ATS Score","Keyword Match","Format Score","Section Score"]:
            df[col] = df[col].apply(lambda x: f"{x*100:.1f}%" if pd.notnull(x) else "N/A")

        c1, c2 = st.columns(2)
        with c1:
            role_filter = st.selectbox("Filter by Role",
                                       ["All"] + list(df["Target Role"].dropna().unique()),
                                       key="role_filter")
        with c2:
            cat_filter = st.selectbox("Filter by Category",
                                      ["All"] + list(df["Target Category"].dropna().unique()),
                                      key="category_filter")

        fdf = df.copy()
        if role_filter != "All": fdf = fdf[fdf["Target Role"] == role_filter]
        if cat_filter  != "All": fdf = fdf[fdf["Target Category"] == cat_filter]

        st.dataframe(fdf, use_container_width=True, hide_index=True)

        c1, c2 = st.columns(2)
        with c1:
            buf = BytesIO(); fdf.to_excel(buf, index=False, engine="openpyxl"); buf.seek(0)
            st.download_button("Download Filtered", data=buf,
                               file_name=f"filtered_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               key="dl_filtered")
        with c2:
            buf2 = BytesIO(); df.to_excel(buf2, index=False, engine="openpyxl"); buf2.seek(0)
            st.download_button("Download All", data=buf2,
                               file_name=f"all_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               key="dl_all")

    def render_admin_section(self):
        self.render_resume_data_section()
        st.markdown("<h2 class='section-title'>Admin Logs</h2>", unsafe_allow_html=True)
        logs = self.get_admin_logs()
        if not logs:
            st.info("No admin logs yet.")
            return
        df = pd.DataFrame(logs, columns=["Admin Email","Action","Timestamp"])
        st.dataframe(df, use_container_width=True, hide_index=True)
        buf = BytesIO(); df.to_excel(buf, index=False, engine="openpyxl"); buf.seek(0)
        st.download_button("Download Logs", data=buf,
                           file_name=f"logs_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           key="dl_logs")

    # ── Main render ───────────────────────────────────────────────────────────

    def render_dashboard(self):
        st.markdown("""<style>
        .dashboard-container {
            background:linear-gradient(135deg,#1e3c72,#2a5298);
            padding:2rem;border-radius:20px;margin-bottom:2rem;
            box-shadow:0 8px 32px rgba(0,0,0,.15);
        }
        .dashboard-title{color:#4FD1C5;font-size:2.2rem;margin-bottom:.5rem;}
        .stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;margin-top:2rem;}
        .stat-card{background:rgba(255,255,255,.05);backdrop-filter:blur(10px);
            padding:1.5rem;border-radius:16px;border:1px solid rgba(255,255,255,.1);
            transition:all .3s ease;}
        .stat-card:hover{transform:translateY(-5px);background:rgba(255,255,255,.1);}
        .stat-value{font-size:2.2rem;font-weight:bold;margin:0;color:#4FD1C5;}
        .stat-label{font-size:.95rem;color:rgba(255,255,255,.7);margin:.4rem 0 0;}
        .trend-indicator{display:inline-flex;align-items:center;padding:.2rem .5rem;
            border-radius:12px;font-size:.85rem;margin-left:.5rem;}
        .trend-up{background:rgba(46,204,113,.2);color:#2ecc71;}
        .trend-down{background:rgba(231,76,60,.2);color:#e74c3c;}
        .section-title{color:#4FD1C5;font-size:1.4rem;margin:1.5rem 0 .5rem;
            padding-bottom:.5rem;border-bottom:2px solid rgba(79,209,197,.2);}
        .chart-container{background:rgba(255,255,255,.05);border-radius:16px;
            padding:1rem;margin-bottom:1rem;}
        .insights-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
            gap:1.5rem;margin-top:1rem;}
        .insight-card{background:rgba(255,255,255,.05);padding:1.5rem;border-radius:16px;
            border:1px solid rgba(255,255,255,.1);}
        @media(max-width:768px){.stats-grid{grid-template-columns:repeat(2,1fr);}}
        </style>""", unsafe_allow_html=True)

        # Header
        st.markdown(f"""
        <div class="dashboard-container">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div class="dashboard-title">📊  Resume Analytics</div>
            
          </div>""", unsafe_allow_html=True)

        stats = self.get_quick_stats()
        ti    = self.get_trend_indicators()
        st.markdown("""
        <div class="stats-grid">
          <div class="stat-card">
            <p class="stat-value">{tr}</p><p class="stat-label">Total Resumes</p>
            <span class="trend-indicator {tc}">{ti} {tv}%</span>
          </div>
          <div class="stat-card">
            <p class="stat-value">{ar}</p><p class="stat-label">Avg ATS Score</p>
            <span class="trend-indicator {ac}">{ai} {av}%</span>
          </div>
          <div class="stat-card">
            <p class="stat-value">{hr}</p><p class="stat-label">High Performing</p>
            <span class="trend-indicator {hc}">{hi} {hv}%</span>
          </div>
          <div class="stat-card">
            <p class="stat-value">{sr}</p><p class="stat-label">Success Rate</p>
            <span class="trend-indicator {sc}">{si} {sv}%</span>
          </div>
        </div></div>
        """.format(
            tr=stats["Total Resumes"],
            tc=ti["resumes"]["class"], ti=ti["resumes"]["icon"], tv=ti["resumes"]["value"],
            ar=stats["Avg ATS Score"],
            ac=ti["ats"]["class"],    ai=ti["ats"]["icon"],     av=ti["ats"]["value"],
            hr=stats["High Performing"],
            hc=ti["high_performing"]["class"], hi=ti["high_performing"]["icon"], hv=ti["high_performing"]["value"],
            sr=stats["Success Rate"],
            sc=ti["success_rate"]["class"],    si=ti["success_rate"]["icon"],    sv=ti["success_rate"]["value"],
        ), unsafe_allow_html=True)

        # Charts
        st.markdown('<div class="section-title">Performance Analytics</div>',
                    unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            st.plotly_chart(
                self.create_enhanced_ats_gauge(
                    float(stats["Avg ATS Score"].rstrip("%"))),
                use_container_width=True, config=_NO_MB)
            st.markdown("</div>", unsafe_allow_html=True)
        with c2:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            st.plotly_chart(self.create_skill_distribution_chart(),
                            use_container_width=True, config=_NO_MB)
            st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="chart-container">', unsafe_allow_html=True)
        st.plotly_chart(self.create_job_category_chart(),
                        use_container_width=True, config=_NO_MB)
        st.markdown("</div>", unsafe_allow_html=True)

        # Insights
        st.markdown('<div class="section-title">Key Insights</div>',
                    unsafe_allow_html=True)
        insights = self.get_detailed_insights()
        if insights:
            st.markdown('<div class="insights-grid">', unsafe_allow_html=True)
            for ins in insights:
                st.markdown(f"""
                <div class="insight-card">
                  <h3 style="color:#4FD1C5;margin-bottom:.8rem;">
                    {ins['icon']} {ins['title']}
                  </h3>
                  <p style="color:rgba(255,255,255,.7);margin:0;">{ins['description']}</p>
                  <div style="margin-top:1rem;">
                    <span class="trend-indicator {ins['trend_class']}">
                      {ins['trend_icon']} {ins['trend_value']}
                    </span>
                  </div>
                </div>""", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

        # Admin section
        if st.session_state.get("is_admin", False):
            self.render_admin_section()