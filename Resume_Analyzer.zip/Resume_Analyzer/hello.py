import pyautogui
import time

print("Open Notepad in 5 seconds...")
time.sleep(5)

messages = [
    "pawan Kumar",
    "Santosh Kushwaha❤️"
]

for i in range(10):
    pyautogui.write(messages[i % 2])
    pyautogui.press("enter")
    time.sleep(0.2)

print("Done!")