﻿"""
Resume Analyzer - Main Application
Upgraded with Recruiter Interface + Batch Resume Analysis
"""
import time
import io
import base64
import json
import traceback
import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from PIL import Image
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

from jobs.job_search import render_job_search
from ui_components import (
    apply_modern_styles, hero_section, feature_card, about_section,
    page_header, render_analytics_section, render_activity_section,
    render_suggestions_section
)
from feedback.feedback import FeedbackManager
from dashboard.dashboard import DashboardManager
from config.courses import COURSES_BY_CATEGORY, RESUME_VIDEOS, INTERVIEW_VIDEOS, get_courses_for_role, get_category_for_role
from config.job_roles import JOB_ROLES
from config.database import (
    get_database_connection, save_resume_data, save_analysis_data,
    init_database, verify_admin, log_admin_action, save_ai_analysis_data,
    get_ai_analysis_stats, reset_ai_analysis_stats, get_detailed_ai_analysis_stats
)
from utils.ai_resume_analyzer import AIResumeAnalyzer
from utils.resume_builder import ResumeBuilder
from utils.resume_analyzer import ResumeAnalyzer

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Resume Analyzer",
    page_icon="🤖",
    layout="wide"
)

st.markdown("""
<style>
#MainMenu { visibility: hidden; }
header[data-testid="stHeader"] { display: none !important; }
footer { visibility: hidden; }
.block-container { padding-top: 1rem !important; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
#  Recruiter Interface helpers
# ─────────────────────────────────────────────────────────────────────────────

def render_recruiter_interface(analyzer: "ResumeAnalyzer", job_roles: dict):
    """Full recruiter panel: batch upload up to 10 resumes, rank by criteria."""

    # ── Header ────────────────────────────────────────────────────────────────
    st.markdown("""
    <div class="recruiter-hero">
        <div class="rh-badge">RECRUITER MODE</div>
        <h1 class="rh-title">Batch Resume Screener</h1>
        <p class="rh-sub">Upload up to 10 resumes and rank candidates instantly against your criteria</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Criteria panel ────────────────────────────────────────────────────────
    with st.expander("⚙️  Screening Criteria", expanded=True):
        col1, col2 = st.columns(2)

        with col1:
            categories = list(job_roles.keys())
            sel_cat = st.selectbox("Job Category", categories, key="rec_cat")
            roles = list(job_roles[sel_cat].keys())
            sel_role = st.selectbox("Target Role", roles, key="rec_role")
            role_info = job_roles[sel_cat][sel_role]

        with col2:
            st.markdown("**Scoring Weights** (must total 100)")
            w_skills   = st.slider("Skills Match %",   0, 100, 50, 5, key="w_skills")
            w_exp      = st.slider("Experience %",     0, 20, 5, 5, key="w_exp")
            w_edu      = st.slider("Education %",      0, 100, 25, 5, key="w_edu")
            w_format   = st.slider("Resume Format %",  0, 100, 20, 5, key="w_format")
            total_w    = w_skills + w_exp + w_edu + w_format
            weight_ok  = (total_w == 100)
            color      = "#4CAF50" if weight_ok else "#FF4444"
            st.markdown(f"<p style='color:{color};font-weight:600;'>Total: {total_w}/100</p>",
                        unsafe_allow_html=True)

        # Custom keywords
        custom_kw = st.text_input(
            "Must-have keywords (comma-separated)",
            placeholder="e.g.  Python, AWS, Docker, 5 years experience",
            key="rec_kw"
        )
        custom_keywords = [k.strip().lower() for k in custom_kw.split(",") if k.strip()]

        # Min experience
        min_exp = st.number_input("Minimum years of experience (0 = no minimum)",
                                  min_value=0, max_value=30, value=0, key="rec_min_exp")

    # ── File upload ───────────────────────────────────────────────────────────
    st.markdown("### 📁 Upload Resumes")
    uploaded_files = st.file_uploader(
        "Select up to 20 resumes (PDF or DOCX)",
        type=["pdf", "docx"],
        accept_multiple_files=True,
        key="rec_files"
    )

    if uploaded_files:
        if len(uploaded_files) > 10:
            st.warning("⚠️ Maximum 10 resumes at a time. Only the first 10 will be processed.")
            uploaded_files = uploaded_files[:10]

        st.info(f"📂 {len(uploaded_files)} file(s) selected")

        analyze_btn = st.button(
            f"🔍  Analyze & Rank {len(uploaded_files)} Resumes",
            type="primary",
            use_container_width=True,
            disabled=not weight_ok,
            key="rec_analyze_btn"
        )
        if not weight_ok:
            st.caption("⚠️ Fix scoring weights to total 100 before analyzing.")

        if analyze_btn:
            _run_batch_analysis(
                uploaded_files, analyzer, role_info, sel_role, sel_cat,
                w_skills, w_exp, w_edu, w_format,
                custom_keywords, min_exp
            )


def _run_batch_analysis(files, analyzer, role_info, sel_role, sel_cat,
                        w_skills, w_exp, w_edu, w_format,
                        custom_keywords, min_exp):
    """Extract, analyse, score and rank all uploaded resumes."""

    results = []
    progress = st.progress(0, text="Starting analysis…")

    for idx, f in enumerate(files):
        progress.progress(int((idx / len(files)) * 90),
                          text=f"Analysing {f.name}…")
        try:
            # ── Extract text ──────────────────────────────────────────────
            f.seek(0)
            if f.type == "application/pdf":
                text = analyzer.extract_text_from_pdf(f)
            elif "wordprocessingml" in f.type:
                text = analyzer.extract_text_from_docx(f)
            else:
                text = f.getvalue().decode("utf-8", errors="ignore")

            if not text or not text.strip():
                results.append({"name": f.name, "error": "Could not extract text"})
                continue

            # ── Standard analysis ─────────────────────────────────────────
            analysis = analyzer.analyze_resume({"raw_text": text}, role_info)
            if "error" in analysis:
                results.append({"name": f.name, "error": analysis["error"]})
                continue

            # ── Custom keyword match ───────────────────────────────────────
            text_lower = text.lower()
            kw_hit  = sum(1 for k in custom_keywords if k in text_lower)
            kw_pct  = (kw_hit / len(custom_keywords) * 100) if custom_keywords else 100
            missing_kw = [k for k in custom_keywords if k not in text_lower]

            # ── Experience gate ────────────────────────────────────────────
            exp_years = _estimate_experience_years(text)
            exp_gate  = (exp_years >= min_exp) if min_exp > 0 else True

            # ── Weighted composite score ──────────────────────────────────
            skill_score  = analysis.get("keyword_match", {}).get("score", 0)
            format_score = analysis.get("format_score", 0)
            edu_score    = analysis.get("section_score", 0)   # proxy for edu
            exp_score    = min(exp_years / max(min_exp, 1) * 100, 100) if min_exp > 0 else 70

            composite = (
                skill_score  * (w_skills / 100) +
                exp_score    * (w_exp    / 100) +
                edu_score    * (w_edu    / 100) +
                format_score * (w_format / 100)
            )

            # Apply keyword penalty if custom keywords were set
            if custom_keywords:
                composite = composite * 0.6 + kw_pct * 0.4

            results.append({
                "name":           f.name,
                "composite":      round(composite, 1),
                "ats_score":      analysis.get("ats_score", 0),
                "skill_score":    round(skill_score, 1),
                "format_score":   round(format_score, 1),
                "edu_score":      round(edu_score, 1),
                "exp_years":      exp_years,
                "exp_gate":       exp_gate,
                "kw_match_pct":   round(kw_pct, 1),
                "missing_kw":     missing_kw,
                "missing_skills": analysis.get("keyword_match", {}).get("missing_skills", []),
                "suggestions":    analysis.get("suggestions", []),
                "analysis":       analysis,
                "error":          None,
            })

        except Exception as e:
            results.append({"name": f.name, "error": str(e)})

    progress.progress(100, text="Done!")
    time.sleep(0.3)
    progress.empty()

    # ── Sort by composite score ────────────────────────────────────────────
    valid   = sorted([r for r in results if not r.get("error")],
                     key=lambda x: x["composite"], reverse=True)
    errored = [r for r in results if r.get("error")]

    _render_ranking_results(valid, errored, custom_keywords, min_exp, sel_role)


def _estimate_experience_years(text: str) -> int:
    """Estimate work experience more accurately for freshers."""
    import re

    text_lower = text.lower()

    # Fresher keywords
    fresher_keywords = [
        "fresher", "intern", "internship",
        "student", "college student",
        "no experience", "entry level"
    ]

    # If fresher keywords found → return 0
    if any(word in text_lower for word in fresher_keywords):
        return 0

    # Find work experience patterns only
    exp_patterns = re.findall(
        r'(\d+)\+?\s*(?:years|yrs|year)',
        text_lower
    )

    if exp_patterns:
        return max([int(x) for x in exp_patterns])

    return 0


def _render_ranking_results(valid, errored, custom_keywords, min_exp, sel_role):
    """Render ranked cards + comparison table + export."""

    if not valid:
        st.error("No resumes could be analysed successfully.")
        if errored:
            for e in errored:
                st.warning(f"❌ {e['name']}: {e['error']}")
        return

    st.markdown("---")
    st.markdown("##  Candidate Rankings")
    st.caption(f"Role: **{sel_role}**  •  {len(valid)} candidates analysed")

    # ── Medal row ─────────────────────────────────────────────────────────
    medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 10

    for rank, r in enumerate(valid):
        medal   = medals[rank]
        score   = r["composite"]
        color   = "#4CAF50" if score >= 75 else "#FFA500" if score >= 50 else "#FF4444"
        gate_ok = r["exp_gate"]
        gate_txt = "" if gate_ok else f"  ⚠️ Below {min_exp}yr exp requirement"

        with st.expander(
            f"{medal} #{rank+1}  |  {r['name']}  —  **{score}/100**{gate_txt}",
            expanded=(rank < 3)
        ):
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Composite",    f"{r['composite']}/100")
            c2.metric("ATS Score",    f"{r['ats_score']}/100")
            c3.metric("Skills Match", f"{r['skill_score']}%")
            c4.metric("Format",       f"{r['format_score']}%")

            # Radar / bar chart
            fig = go.Figure(go.Bar(
                x=["Skills", "Format", "Education", "Exp Est."],
                y=[r["skill_score"], r["format_score"], r["edu_score"],
                   min(r["exp_years"] * 10, 100)],
                marker_color=[color, "#00B4DB", "#8B5CF6", "#F59E0B"],
                text=[f"{v:.0f}" for v in [r["skill_score"], r["format_score"],
                      r["edu_score"], min(r["exp_years"] * 10, 100)]],
                textposition="auto",
            ))
            fig.update_layout(
                height=220, margin=dict(l=10, r=10, t=20, b=10),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#E0E0E0"), yaxis=dict(range=[0, 100]),
                showlegend=False,
            )
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

            # Keyword coverage
            if custom_keywords:
                hit = [k for k in custom_keywords if k not in r["missing_kw"]]
                st.markdown(
                    f"**Keyword Coverage:** {len(hit)}/{len(custom_keywords)} "
                    f"({r['kw_match_pct']}%)"
                )
                if r["missing_kw"]:
                    st.markdown(
                        "Missing: " +
                        "  ".join(f"`{k}`" for k in r["missing_kw"])
                    )

            # Missing skills
            if r["missing_skills"]:
                st.markdown("**Missing Role Skills:** " +
                            ", ".join(r["missing_skills"][:8]))

            # Top suggestions
            if r["suggestions"]:
                with st.container():
                    st.markdown("**Top Suggestions:**")
                    for s in r["suggestions"][:3]:
                        st.markdown(f"- {s}")

    # ── Comparison table ──────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 📊 Side-by-Side Comparison")

    df = pd.DataFrame([{
        "Rank":         f"#{i+1}",
        "File":         r["name"],
        "Composite":    r["composite"],
        "ATS":          r["ats_score"],
        "Skills %":     r["skill_score"],
        "Format %":     r["format_score"],
        "Exp (yrs)":    r["exp_years"],
        "KW Match %":   r["kw_match_pct"] if custom_keywords else "N/A",
        "Exp Gate":     "✅" if r["exp_gate"] else "❌",
    } for i, r in enumerate(valid)])

    st.dataframe(df, use_container_width=True, hide_index=True)

    # ── Composite score chart ─────────────────────────────────────────────
    fig2 = px.bar(
        df, x="File", y="Composite",
        color="Composite",
        color_continuous_scale=["#FF4444", "#FFA500", "#4CAF50"],
        range_color=[0, 100],
        text="Composite",
        title="Composite Scores — All Candidates",
    )
    fig2.update_layout(
        height=320, paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", font=dict(color="#E0E0E0"),
        coloraxis_showscale=False,
    )
    fig2.update_traces(textposition="outside")
    st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

    # ── Export ────────────────────────────────────────────────────────────
   # st.markdown("---")
    #st.markdown("### 💾 Export Results")
    #csv_buf = df.to_csv(index=False).encode()
    #st.download_button(
     #   "⬇️  Download Rankings CSV",
      #  data=csv_buf,
       # file_name=f"candidate_rankings_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.csv",
        #mime="text/csv",
        #use_container_width=True,
    #)

    # Errors
    if errored:
        st.markdown("---")
        st.markdown("#### ⚠️ Files with errors")
        for e in errored:
            st.warning(f"**{e['name']}**: {e['error']}")


# ─────────────────────────────────────────────────────────────────────────────
#  Main App class
# ─────────────────────────────────────────────────────────────────────────────

class ResumeApp:
    def __init__(self):
        # ── Session state defaults ─────────────────────────────────────────
        if "form_data" not in st.session_state:
            st.session_state.form_data = {
                "personal_info": {
                    "full_name": "", "email": "", "phone": "",
                    "location": "", "linkedin": "", "portfolio": ""
                },
                "summary": "",
                "experiences": [],
                "education": [],
                "projects": [],
                "skills_categories": {
                    "technical": [], "soft": [], "languages": [], "tools": []
                }
            }
        if "page" not in st.session_state:
            st.session_state.page = "home"
        if "is_admin" not in st.session_state:
            st.session_state.is_admin = False
        if "user_id" not in st.session_state:
            st.session_state.user_id = "default_user"
        if "selected_role" not in st.session_state:
            st.session_state.selected_role = None
        if "resume_data" not in st.session_state:
            st.session_state.resume_data = []

        # ── Page registry ──────────────────────────────────────────────────
        self.pages = {
            "🏠 HOME":              self.render_home,
            "👔 RECRUITER":         self.render_recruiter,
            "🔍 RESUME ANALYZER":   self.render_analyzer,
            "📊 DASHBOARD":         self.render_dashboard,
            "🎯 JOB RESEARCH":        self.render_job_search,
            "ℹ️ ABOUT":             self.render_about,
        }

        # ── Core objects ───────────────────────────────────────────────────
        self.dashboard_manager = DashboardManager()
        self.analyzer    = ResumeAnalyzer()
        self.ai_analyzer = AIResumeAnalyzer()
        self.builder     = ResumeBuilder()
        self.job_roles   = JOB_ROLES

        init_database()

        # Load CSS
        with open("style/style.css", encoding="utf-8") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

        st.markdown("""
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        """, unsafe_allow_html=True)

    # ── Utilities ──────────────────────────────────────────────────────────

    def _clean_page_key(self, name: str) -> str:
        """Convert sidebar label → session-state key."""
        for ch in ["🏠", "👔", "🔍", "📝", "📊", "🎯", "💬", "ℹ️"]:
            name = name.replace(ch, "")
        return name.lower().replace(" ", "_").strip()

    def render_empty_state(self, icon, message):
        return f"""
        <div style='text-align:center;padding:2rem;color:#666;'>
            <i class='{icon}' style='font-size:2rem;margin-bottom:1rem;color:#00B4DB;'></i>
            <p style='margin:0;'>{message}</p>
        </div>"""

    # ── Pages ──────────────────────────────────────────────────────────────

    def render_home(self):
        apply_modern_styles()

        # Hero
        st.markdown("""
        <div class="home-hero">
            <div class="home-hero-badge">AI-POWERED CAREER TOOL</div>
            <h1 class="home-hero-title">RESUME ANALYZER</h1>
            <p class="home-hero-sub">
                Transform your career with AI-powered resume analysis.
                Get personalised insights and stand out from the crowd.
            </p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("### What would you like to do?")

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("""
            <div class="hc-wrap">
              <div class="hc-icon-wrap"><i class="fas fa-file-alt"></i></div>
              <div class="hc-body">
                <div class="hc-title">Resume Analyzer</div>
                <div class="hc-desc">Instant ATS score, skills gap analysis, and section-by-section feedback on your resume.</div>
                <div class="hc-tag">Most Popular</div>
              </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("Open Resume Analyzer →", key="home_analyzer",
                         use_container_width=True):
                st.session_state.page = "resume_analyzer"
                st.rerun()

        with c2:
            st.markdown("""
            <div class="hc-wrap">
              <div class="hc-icon-wrap" style="background:rgba(139,92,246,.15);border-color:rgba(139,92,246,.35);">
                <i class="fas fa-user-tie" style="color:#8B5CF6;"></i>
              </div>
              <div class="hc-body">
                <div class="hc-title">Recruiter Mode</div>
                <div class="hc-desc">Batch screen &amp; rank up to 10 resumes with custom weights and keyword filters.</div>
                <div class="hc-tag" style="background:rgba(139,92,246,.15);color:#8B5CF6;border-color:rgba(139,92,246,.4);">For Recruiters</div>
              </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("Open Recruiter Mode →", key="home_recruiter",
                         use_container_width=True):
                st.session_state.page = "recruiter"
                st.rerun()

        c3, c4 = st.columns(2)
        with c3:
            st.markdown("""
            <div class="hc-wrap">
              <div class="hc-icon-wrap" style="background:rgba(245,158,11,.12);border-color:rgba(245,158,11,.35);">
                <i class="fas fa-chart-bar" style="color:#F59E0B;"></i>
              </div>
              <div class="hc-body">
                <div class="hc-title">Career Dashboard</div>
                <div class="hc-desc">Track your resume history, analysis trends, and career progress over time.</div>
                <div class="hc-tag" style="background:rgba(245,158,11,.12);color:#F59E0B;border-color:rgba(245,158,11,.4);">Analytics</div>
              </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("Open Dashboard →", key="home_dashboard",
                         use_container_width=True):
                st.session_state.page = "dashboard"
                st.rerun()

        with c4:
            st.markdown("""
            <div class="hc-wrap">
              <div class="hc-icon-wrap" style="background:rgba(34,197,94,.12);border-color:rgba(34,197,94,.35);">
                <i class="fas fa-briefcase" style="color:#22C55E;"></i>
              </div>
              <div class="hc-body">
                <div class="hc-title">Job Research</div>
                <div class="hc-desc">Discover relevant openings matched to your target role and skill profile.</div>
                <div class="hc-tag" style="background:rgba(34,197,94,.12);color:#22C55E;border-color:rgba(34,197,94,.4);"> Jobs Trends</div>
              </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("Open Job Research →", key="home_jobs",
                         use_container_width=True):
                st.session_state.page = "job_search"
                st.rerun()

        # Stats strip
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("""
        <div class="home-stats">
          <div class="hs-item"><div class="hs-val">5+</div><div class="hs-lbl">Job Categories</div></div>
          <div class="hs-sep"></div>
          <div class="hs-item"><div class="hs-val">Batch</div><div class="hs-lbl">Up to 10 Resumes</div></div>
          <div class="hs-sep"></div>
          <div class="hs-item"><div class="hs-val">ATS</div><div class="hs-lbl">Score & Insights</div></div>
          <div class="hs-sep"></div>
          <div class="hs-item"><div class="hs-val">Free</div><div class="hs-lbl">No Sign-up Needed</div></div>
        </div>
        """, unsafe_allow_html=True)

    def render_recruiter(self):
        apply_modern_styles()
        render_recruiter_interface(self.analyzer, self.job_roles)

    def render_dashboard(self):
        self.dashboard_manager.render_dashboard()

    def render_job_search(self):
        render_job_search()

    def render_about(self):
        apply_modern_styles()

        st.markdown("""
        <div class="about-hero">
            <h1>About Smart Resume AI</h1>
            <p>A powerful AI-driven platform for optimising your resume and accelerating your career.</p>
        </div>

        <div class="about-grid">
          <div class="about-card">
            <i class="fas fa-robot fa-2x" style="color:#00B4DB;margin-bottom:1rem;"></i>
            <h3>AI-Powered Analysis</h3>
            <p>Advanced algorithms identify strengths, gaps, and give section-by-section feedback.</p>
          </div>
          <div class="about-card">
            <i class="fas fa-users fa-2x" style="color:#00B4DB;margin-bottom:1rem;"></i>
            <h3>Recruiter Tools</h3>
            <p>Batch screen candidates, set custom weights, and export ranked shortlists in seconds.</p>
          </div>
          <div class="about-card">
            <i class="fas fa-shield-alt fa-2x" style="color:#00B4DB;margin-bottom:1rem;"></i>
            <h3>Privacy First</h3>
            <p>Your data is processed locally. We never store or sell your resume content.</p>
          </div>
        </div>
        """, unsafe_allow_html=True)

    def render_analyzer(self):
        """Single-resume standard analyser."""
        apply_modern_styles()
        page_header("Resume Analyzer", "Get instant AI-powered feedback to optimise your resume")

        categories    = list(self.job_roles.keys())
        sel_cat       = st.selectbox("Job Category", categories, key="std_cat")
        roles         = list(self.job_roles[sel_cat].keys())
        sel_role      = st.selectbox("Specific Role", roles, key="std_role")
        role_info     = self.job_roles[sel_cat][sel_role]

        st.markdown(f"""
        <div class="role-info-box">
            <h4>{sel_role}</h4>
            <p>{role_info['description']}</p>
            <p><strong>Required:</strong> {', '.join(role_info['required_skills'])}</p>
        </div>
        """, unsafe_allow_html=True)

        uploaded = st.file_uploader("Upload your resume", type=["pdf", "docx"], key="std_file")

        if not uploaded:
            st.markdown(
                self.render_empty_state("fas fa-cloud-upload-alt",
                                        "Upload your resume (PDF or DOCX) to get started"),
                unsafe_allow_html=True
            )
            return

        if st.button("🔍  Analyze My Resume", type="primary", use_container_width=True):
            with st.spinner("Analysing your resume…"):
                try:
                    uploaded.seek(0)
                    if uploaded.type == "application/pdf":
                        text = self.analyzer.extract_text_from_pdf(uploaded)
                    elif "wordprocessingml" in uploaded.type:
                        text = self.analyzer.extract_text_from_docx(uploaded)
                    else:
                        text = uploaded.getvalue().decode("utf-8", errors="ignore")

                    if not text or not text.strip():
                        st.error("Could not extract text from this file. Please try another.")
                        return

                    analysis = self.analyzer.analyze_resume({"raw_text": text}, role_info)
                    if "error" in analysis:
                        st.error(analysis["error"])
                        return

                    if analysis.get("document_type") != "resume":
                        st.error(f"⚠️ This looks like a {analysis['document_type']}, not a resume.")
                        return

                except Exception as e:
                    st.error(f"Error: {e}")
                    return

            # ── Results ───────────────────────────────────────────────────
            st.markdown("---")
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("ATS Score",     f"{analysis.get('ats_score', 0)}/100")
            c2.metric("Skills Match",  f"{int(analysis.get('keyword_match', {}).get('score', 0))}%")
            c3.metric("Format Score",  f"{int(analysis.get('format_score', 0))}%")
            c4.metric("Section Score", f"{int(analysis.get('section_score', 0))}%")

            left, right = st.columns(2)

            with left:
                st.markdown("#### 🎯 Missing Skills")
                missing = analysis.get("keyword_match", {}).get("missing_skills", [])
                if missing:
                    for skill in missing:
                        st.markdown(f"- `{skill}`")
                else:
                    st.success("All key skills detected!")

            with right:
                st.markdown("#### 💡 Suggestions")
                for suggestion in (analysis.get("suggestions") or [])[:6]:
                    st.markdown(f"- {suggestion}")

            # Save to DB (silently)
            try:
                resume_data = {
                    "personal_info": {
                        "name": analysis.get("name", ""),
                        "email": analysis.get("email", ""),
                        "phone": analysis.get("phone", ""),
                        "linkedin": analysis.get("linkedin", ""),
                        "github": analysis.get("github", ""),
                        "portfolio": analysis.get("portfolio", ""),
                    },
                    "summary": analysis.get("summary", ""),
                    "target_role": sel_role,
                    "target_category": sel_cat,
                    "education": analysis.get("education", []),
                    "experience": analysis.get("experience", []),
                    "projects": analysis.get("projects", []),
                    "skills": analysis.get("skills", []),
                    "template": "",
                }
                resume_id = save_resume_data(resume_data)
                analysis_data = {
                    "resume_id": resume_id,
                    "ats_score": analysis["ats_score"],
                    "keyword_match_score": analysis["keyword_match"]["score"],
                    "format_score": analysis["format_score"],
                    "section_score": analysis["section_score"],
                    "missing_skills": ",".join(analysis["keyword_match"]["missing_skills"]),
                    "recommendations": ",".join(analysis["suggestions"]),
                }
                save_analysis_data(resume_id, analysis_data)
            except Exception:
                pass  # DB errors are non-fatal

    # ── Sidebar + routing ──────────────────────────────────────────────────

    def add_footer(self):
        st.markdown("<hr style='margin-top:50px;margin-bottom:20px;opacity:0.2;'>",
                    unsafe_allow_html=True)
        st.markdown(
            "<p style='text-align:center;color:#666;font-size:0.85rem;'>"
            "Smart Resume AI · Built with Streamlit &amp; Python</p>",
            unsafe_allow_html=True
        )

    def main(self):
        # ── Global styles ──────────────────────────────────────────────────
        st.markdown("""
        <style>
        /* ─── Recruiter hero ─────────────────────────────────────────── */
        .recruiter-hero {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            border-radius: 16px;
            padding: 3rem 2.5rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(0,180,219,.25);
            position: relative; overflow: hidden;
        }
        .recruiter-hero::before {
            content:''; position:absolute; inset:0;
            background: radial-gradient(ellipse at top left, rgba(0,180,219,.15), transparent 60%);
        }
        .rh-badge {
            display:inline-block; background:rgba(0,180,219,.15);
            color:#00B4DB; border:1px solid rgba(0,180,219,.4);
            border-radius:20px; padding:.3rem 1rem;
            font-size:.75rem; font-weight:700; letter-spacing:2px;
            margin-bottom:1rem;
        }
        .rh-title { font-size:2.4rem; font-weight:700; color:#fff; margin:0 0 .5rem; }
        .rh-sub   { color:#9BB8C9; font-size:1.05rem; margin:0; }

        /* ─── Home hero ──────────────────────────────────────────────── */
        .home-hero {
            background: linear-gradient(135deg, #0f2027 0%, #1a3040 50%, #0E1117 100%);
            border: 1px solid rgba(0,180,219,.2);
            border-radius: 18px; padding: 3.5rem 3rem;
            margin-bottom: 2rem; position: relative; overflow: hidden;
        }
        .home-hero::before {
            content:''; position:absolute; top:-60px; right:-60px;
            width:320px; height:320px;
            background: radial-gradient(circle, rgba(0,180,219,.18), transparent 65%);
            pointer-events:none;
        }
        .home-hero-badge {
            display:inline-block; background:rgba(0,180,219,.12);
            color:#00B4DB; border:1px solid rgba(0,180,219,.35);
            border-radius:20px; padding:.3rem 1rem;
            font-size:.7rem; font-weight:700; letter-spacing:2px; margin-bottom:1.2rem;
        }
        .home-hero-title {
            font-size:3rem; font-weight:700; margin:0 0 1rem; line-height:1.15;
            background: linear-gradient(135deg,#fff 30%,#9BB8C9 100%);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .home-hero-sub {
            font-size:1.1rem; color:#9BB8C9; margin:0; line-height:1.7; max-width:600px;
        }
        /* ─── Home feature cards ─────────────────────────────────────── */
        .hc-wrap {
            background:rgba(20,30,40,.8); border:1px solid rgba(255,255,255,.07);
            border-radius:14px; padding:1.5rem; margin-bottom:.6rem;
            display:flex; gap:1.1rem; align-items:flex-start;
            transition:all .25s ease; min-height:130px;
        }
        .hc-wrap:hover {
            border-color:rgba(0,180,219,.4); background:rgba(25,38,52,.9);
            transform:translateY(-3px); box-shadow:0 8px 28px rgba(0,0,0,.4);
        }
        .hc-icon-wrap {
            flex-shrink:0; width:46px; height:46px;
            background:rgba(0,180,219,.12); border:1px solid rgba(0,180,219,.3);
            border-radius:10px; display:flex; align-items:center;
            justify-content:center; font-size:1.2rem; color:#00B4DB;
        }
        .hc-body { flex:1; }
        .hc-title { font-size:1rem; font-weight:700; color:#E8EDF2; margin-bottom:.35rem; }
        .hc-desc  { font-size:.85rem; color:#7A9AAB; line-height:1.55; margin-bottom:.6rem; }
        .hc-tag {
            display:inline-block; font-size:.68rem; font-weight:600;
            background:rgba(0,180,219,.1); color:#00B4DB;
            border:1px solid rgba(0,180,219,.3);
            border-radius:10px; padding:.15rem .6rem; letter-spacing:.5px;
        }
        /* ─── Stats strip ────────────────────────────────────────────── */
        .home-stats {
            display:flex; align-items:center; justify-content:center;
            background:rgba(20,30,40,.6); border:1px solid rgba(255,255,255,.07);
            border-radius:14px; padding:1.25rem 2rem; flex-wrap:wrap;
        }
        .hs-item { text-align:center; padding:.5rem 2rem; }
        .hs-val  { font-size:1.5rem; font-weight:700; color:#00B4DB; }
        .hs-lbl  { font-size:.75rem; color:#5A7A8A; margin-top:.2rem;
                   text-transform:uppercase; letter-spacing:.8px; }
        .hs-sep  { width:1px; height:40px; background:rgba(255,255,255,.08); flex-shrink:0; }

        /* ─── Role info ──────────────────────────────────────────────── */
        .role-info-box {
            background:rgba(0,180,219,.08); border:1px solid rgba(0,180,219,.25);
            border-radius:10px; padding:1.25rem 1.5rem; margin:1rem 0;
        }
        .role-info-box h4 { color:#00B4DB; margin:0 0 .4rem; }
        .role-info-box p  { color:#C0C8D0; margin:.25rem 0; font-size:.92rem; }

        /* ─── About ──────────────────────────────────────────────────── */
        .about-hero { text-align:center; padding:3rem 1rem 2rem; }
        .about-hero h1 { font-size:2.6rem; color:#00B4DB; }
        .about-hero p  { color:#9BB8C9; font-size:1.1rem; }
        .about-grid {
            display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
            gap:1.5rem; margin:2rem 0;
        }
        .about-card {
            background:rgba(30,40,50,.7); border:1px solid rgba(255,255,255,.08);
            border-radius:14px; padding:2rem 1.5rem; text-align:center;
        }
        .about-card h3 { color:#E0E0E0; margin:.75rem 0 .5rem; }
        .about-card p  { color:#8A9BAB; font-size:.9rem; margin:0; }
        </style>
        """, unsafe_allow_html=True)

        # ── Sidebar ────────────────────────────────────────────────────────
        with st.sidebar:
            st.image("assets/resume.png", width=200)
            st.markdown("""
            <div style="text-align:center;margin-bottom:1.5rem;">
              <div style="font-size:1.15rem;font-weight:700;color:#E8EDF2;letter-spacing:.6px;">RESUME ANALYZER</div>
              <div style="font-size:.75rem;color:#5A7A8A;letter-spacing:1.5px;text-transform:uppercase;margin-top:.2rem;">Career Intelligence</div>
            </div>
            """, unsafe_allow_html=True)

            current_page = st.session_state.get("page", "home")

            nav_items = [
                ("home",           "🏠", "Home"),
                ("recruiter",      "👔", "Recruiter"),
                ("resume_analyzer","🔍", "Resume Analyzer"),
                ("dashboard",      "📊", "Dashboard"),
                ("job_search",     "🎯", "Job Research"),
                ("about",          "ℹ️", "About"),
            ]

            st.markdown("""
            <style>
            div[data-testid="stSidebar"] .nav-label {
                font-size:.7rem; font-weight:600; color:#3A5A6A;
                text-transform:uppercase; letter-spacing:1.5px;
                padding:.5rem 0 .3rem; margin-top:.5rem;
            }
            </style>
            
            """, unsafe_allow_html=True)

            for page_key, icon, label in nav_items:
                is_active = (current_page == page_key)
                btn_style = "primary" if is_active else "secondary"
                prefix = " " if is_active else "   "
                if st.button(
                    f"{icon}  {prefix}{label}",
                    key=f"nav_{page_key}",
                    use_container_width=True,
                    type=btn_style
                ):
                    st.session_state.page = page_key
                    st.rerun()

            

        # ── First-load redirect ────────────────────────────────────────────
        if "initial_load" not in st.session_state:
            st.session_state.initial_load = True
            st.session_state.page = "home"
            st.rerun()

        # ── Route ─────────────────────────────────────────────────────────
        page_map = {
            "home":            self.render_home,
            "recruiter":       self.render_recruiter,
            "resume_analyzer": self.render_analyzer,
            "dashboard":       self.render_dashboard,
            "job_search":      self.render_job_search,
            "about":           self.render_about,
        }
        current = st.session_state.get("page", "home")
        page_map.get(current, self.render_home)()

       # self.add_footer()


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = ResumeApp()
    app.main()